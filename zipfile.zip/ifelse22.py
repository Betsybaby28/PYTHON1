l=int(input("enter the lenght"))
b=int(input("enter the breadth"))
if l==b:
    print("it is square")
else:
    print("not square")