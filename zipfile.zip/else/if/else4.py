n=int(input("enter the quality"))
if n>10:
    total=n * 100 - 100
    print("total=",total)
else:
    total1=n*100
    print("total1=",total1)