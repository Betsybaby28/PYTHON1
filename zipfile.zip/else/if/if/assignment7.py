dict1={}
n=int(input("enter the limit"))
for i in range(1,n):
    k=i
    v=i*i
    dict1[k]=v
print(dict1)
