i=int(input("enter the first integer"))
n=int(input("enter the second integer"))
if i>n:
    print("first integer is greater")
else:
    print("second integer is greater")
