s=int(input("enter the salary"))
y=int(input("year of service"))
if y>5:
    n = s * 1.05
    print("net bonus=",n)
else:
    print("no bonus")
